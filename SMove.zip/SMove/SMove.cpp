/*
  SMove.cpp - Library for Moving Servos some sort of smoothly. Hopefully working.
*/

#include "Arduino.h"
#include "SMove.h"

SMove::SMove(int pin)
{
  _pin = pin;
  pinMode(_pin, OUTPUT);
}

void SMove::movePos(int degree)
{
  _repeat = 20;
  while(_repeat > 0){
    _degree = map(degree,0,180,544,2400);
    delay(15);
    AdditionalDelay = 5000 - _degree;
    delayMicroseconds(AdditionalDelay);
    //Puls
    digitalWrite(_pin, HIGH);
    delayMicroseconds(_degree);
    digitalWrite(_pin, LOW);
    _repeat = _repeat - 1;
  }
  _repeat = 20;
}
