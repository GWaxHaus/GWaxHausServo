/*
  SMove.h - Library for Moving Servos some sort of smoothly. Hopefully working.
*/

#ifndef SMove_h
#define SMove_h

#include "Arduino.h"

class SMove
{
    public:
        SMove(int pin);
        void movePos(int degree);
    private:
        int _pin;
        int _degree;
        int _repeat;
        int AdditionalDelay;
};

#endif